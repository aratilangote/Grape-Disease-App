package com.capstoneProject.grapebhumi;

public class youtubevideo {
    String videoUrl;
    public youtubevideo(){}
    public youtubevideo(String videoUrl){
        this.videoUrl=videoUrl;
    }
    public  String getVideourl(){
        return videoUrl;
    }
    public void setVideoUrl(String videoUrl){
        this.videoUrl=videoUrl;
    }

}
